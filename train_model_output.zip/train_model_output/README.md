# Breast Cancer Classification - Output Screenshots

This folder contains high-resolution terminal execution screenshots and visualization plot outputs for each part of `train_model.py`.

---

## Output Screenshots Catalog

### Part 1: Data Loading
* **`01_part1_data_loading_terminal_output.png`**:
  * Shows dataset path (`data/data.csv`), shape (`569 rows x 33 columns`), first 5 rows, list of 33 column names, `df.info()`, `df.describe()` 8-point summary, missing value count (569 nulls in `Unnamed: 32`), and duplicate row count (0).

### Part 2: Data Cleaning
* **`02_part2_data_cleaning_terminal_output.png`**:
  * Shows dropping of empty `Unnamed: 32` column and non-predictive `id` patient identifier column.
  * Shows target class counts and proportions (`B`: 357, 62.74%; `M`: 212, 37.26%).
  * Shows separated feature matrix $X$ (`569 x 30`) and target vector $y$ (`569,`).

### Part 3: Exploratory Data Analysis (EDA)
* **`03_part3_eda_terminal_output.png`**:
  * Terminal confirmation of generated plots.
* **`03_part3_eda_all_plots_collage.png`**:
  * Composite multi-panel overview combining all 5 EDA visualizations.
* **`03_part3_plot_target_distribution.png`**:
  * Bar plot of target diagnosis (`Benign` vs `Malignant`).
* **`03_part3_plot_correlation_heatmap.png`**:
  * Pearson correlation heatmap of the 10 mean features.
* **`03_part3_plot_feature_histograms.png`**:
  * Histograms with KDE curves for `radius_mean`, `texture_mean`, `perimeter_mean`, `area_mean`.
* **`03_part3_plot_feature_boxplots.png`**:
  * Box plots comparing distribution by diagnosis.
* **`03_part3_plot_scatter_plot.png`**:
  * 2D feature separation scatter plot (`radius_mean` vs `texture_mean`).

### Part 4: Data Preprocessing
* **`04_part4_preprocessing_terminal_output.png`**:
  * 80:20 stratified train/test split (455 training samples, 114 testing samples).
  * Feature standardization using `StandardScaler` fitted strictly on training data to avoid data leakage.

### Part 5: Training Machine Learning Models
* **`05_part5_models_training_terminal_output.png`**:
  * Training execution for Gaussian Naive Bayes (`GaussianNB`), Logistic Regression (`LogisticRegression`), and Support Vector Machine (`SVC`).

### Part 6: Model Evaluation
* **`06_part6_model_evaluation_terminal_output.png`**:
  * Complete classification reports, accuracy, precision, recall, and F1-score for each model on the 114 test samples.
  * Detailed clinical explanation of why **False Negatives** matter in cancer detection.
* **`06_part6_plot_confusion_matrices.png`**:
  * Side-by-side heatmaps of the confusion matrices for Gaussian Naive Bayes, Logistic Regression, and SVM.

### Part 7: Model Comparison & Selection
* **`07_part7_model_comparison_terminal_output.png`**:
  * Pandas comparison table ranking the three models.
  * Explanation of why Support Vector Machine was selected as the best performing model.
  * Serialization confirmation saving `model.joblib`.
* **`07_part7_plot_model_accuracy_comparison.png`**:
  * Bar chart comparing test accuracy across all 3 classifiers.

### Interactive Viewer
* **`index.html`**:
  * Standalone HTML webpage that allows you to view all screenshots together in any web browser.
