# Streamlit Web Application Outputs (`app.py`)

This folder contains high-resolution browser interface screenshots capturing every section, visualization view, and prediction state of the Streamlit application for the **Breast Cancer Classification** project.

---

## Web Application Screenshots Catalog

### Section 1: Project Overview
* **`01_project_overview.png`**:
  * Displays the main project title, clinical introduction, list of key project objectives (EDA, preprocessing, model training, evaluation, prediction), and the academic medical disclaimer box.

### Section 2: Dataset Information
* **`02_dataset_information.png`**:
  * Displays the 3 summary metric cards:
    * **Total Samples:** `569`
    * **Benign Samples (B):** `357` (62.7%)
    * **Malignant Samples (M):** `212` (37.3%)
  * Displays the interactive DataFrame preview table for the first 5 rows of `data/data.csv`.
  * Summarizes data cleaning steps (dropping `id` and `Unnamed: 32`, checking duplicates).

### Section 3: Exploratory Data Analysis (EDA) Views
* **`03_eda_target_distribution.png`**:
  * Visualizes the distribution of diagnosis (`Benign` vs `Malignant`) with sample counts and stratified splitting explanation.
* **`03_eda_correlation_heatmap.png`**:
  * Displays the Pearson correlation heatmap for the 10 cell nucleus mean features, explaining feature correlation ($r \approx 0.99$) and its effect on Naive Bayes.
* **`03_eda_feature_histograms.png`**:
  * Displays 4 distribution histograms with KDE curves (`radius_mean`, `texture_mean`, `perimeter_mean`, `area_mean`) comparing malignant vs benign distributions.
* **`03_eda_feature_boxplots.png`**:
  * Displays grouped box plots showing median and quartile differences by diagnosis.
* **`03_eda_scatter_plot.png`**:
  * Displays the 2D feature separation scatter plot (`radius_mean` vs `texture_mean`) showing class cluster boundaries.

### Section 4: Model Comparison & Evaluation
* **`04_model_comparison_and_evaluation.png`**:
  * Displays the Model Performance Comparison Table:
    * **Gaussian Naive Bayes:** Accuracy 93.86%, Precision 1.0000, Recall 0.8333, F1-Score 0.9091
    * **Logistic Regression:** Accuracy 96.49%, Precision 0.9750, Recall 0.9286, F1-Score 0.9512
    * **Support Vector Machine (SVM):** Accuracy 97.37%, Precision 1.0000, Recall 0.9286, F1-Score 0.9630
  * Displays side-by-side graphical charts:
    * **Accuracy Comparison Bar Chart**
    * **Confusion Matrices Heatmap**
  * Explains why SVM was selected as the top model.
  * Details the clinical significance of **False Negatives** in medical screening.

### Section 5: Cancer Diagnosis Prediction
* **`05_prediction_malignant_case.png`**:
  * Demonstrates testing a confirmed Malignant sample (Row 0 from `data.csv`).
  * Shows loaded feature values, button trigger, and the resulting red alert box:
    * **`🚨 Prediction: Malignant (Cancerous)`**
* **`05_prediction_benign_case.png`**:
  * Demonstrates testing a confirmed Benign sample (Row 19 from `data.csv`).
  * Shows loaded feature values, button trigger, and the resulting green alert box:
    * **`✅ Prediction: Benign (Non-Cancerous)`**

---

### Interactive Web Viewer
* **`index.html`**:
  * Open this file in Google Chrome, Microsoft Edge, or any web browser to view all screenshots together in a single clean gallery page.
